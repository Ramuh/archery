package de.ramuh.game.archery;

public class Archery {

}
