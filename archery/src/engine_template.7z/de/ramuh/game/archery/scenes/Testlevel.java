package de.ramuh.game.archery.scenes;

import de.ramuh.game.engine.scene.templates.SideScrollerScene;

public class Testlevel extends SideScrollerScene {

	public Testlevel() {
		super.mapFileName = "data/maps/test1.tmx";
	}
	
}
