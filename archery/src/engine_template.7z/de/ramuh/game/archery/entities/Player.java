package de.ramuh.game.archery.entities;

import de.ramuh.game.engine.entity.Mob;

public class Player extends Mob {

	@Override
	public void tick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render() {
		// TODO Auto-generated method stub
		
	}

}
