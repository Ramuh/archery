package de.ramuh.game.engine.entity;

public abstract class Entity {

	private boolean removed = false;
	
	// advance Scene for delta time 
	public abstract void tick();
	
	// render objects in scene
	public abstract void render();
	
	public void remove() {
		removed = true;
	}
	
	public boolean isRemoved() {
		return removed;
	}
}
