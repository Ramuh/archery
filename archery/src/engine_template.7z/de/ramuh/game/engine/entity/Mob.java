package de.ramuh.game.engine.entity;

public abstract class Mob extends Entity {

	// every mob has a position
	protected int x, y;
}
