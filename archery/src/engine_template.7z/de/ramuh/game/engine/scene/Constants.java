package de.ramuh.game.engine.scene;

public class Constants {

	public static final float DELTA = 1000/60f;

}
