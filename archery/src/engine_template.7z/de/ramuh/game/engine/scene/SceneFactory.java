package de.ramuh.game.engine.scene;

public class SceneFactory {

	public Scene getScene(int id)
	{
		// look up in map or throw error
	
		return null;
	}	
}
