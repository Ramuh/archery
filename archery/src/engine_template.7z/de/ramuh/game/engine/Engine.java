package de.ramuh.game.engine;

import java.util.Stack;

import aurelienribon.tweenengine.TweenManager;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.input.GestureDetector;

import de.ramuh.game.engine.input.InputHandler;
import de.ramuh.game.engine.scene.Constants;
import de.ramuh.game.engine.scene.Scene;
import de.ramuh.game.engine.scene.SceneFactory;

public class Engine implements ApplicationListener {
	
	public static TweenManager tweenManager;
	
	// graphics
	private OrthographicCamera camera;
	private SpriteBatch batch;
	
	public static int widthFactor;
	public static int heightFactor;
	
	// FPS and timers
	private long currTime;
	private long elapsedTime;
	private int fps;
	private long lastFps;
	
	
	// scene mgmt
	public static Scene curr;
	private Stack<Scene> sceneStack;

	private Scene startScene;

	public static int w;
	public static int h;

	public static SceneFactory sf;
	
	public Engine(Scene startScene) {
		this.startScene = startScene;
	}
	
	@Override
	public void create() {
				
		// init gfx
		w = Gdx.graphics.getWidth();
		h = Gdx.graphics.getHeight();
		
		camera = new OrthographicCamera(1, h/w);
		batch = new SpriteBatch();
		
		Gdx.input.setInputProcessor(new GestureDetector(new InputHandler()));
		
		// Init Times and FPS
		this.currTime = System.currentTimeMillis();
		this.elapsedTime = this.currTime;
		this.lastFps = this.currTime;
		this.fps = 0;

		// Init Managers & Factories
		tweenManager = new TweenManager();
		sf = new SceneFactory();
		
		// Init Scene Stack
		this.sceneStack = new Stack<Scene>();
		this.push(startScene); // we put a TestScene in, hopefully nobody pushes out too far ;)
	}

	
	@Override
	public void dispose() {
		batch.dispose();
	}

	////
	
	@Override
	public void render() {		
		this.elapsedTime = System.currentTimeMillis(); // TODO Change to Nanotime for actual 60 fps resolution
		if (this.elapsedTime - this.currTime < 32L)
			tick();
		this.currTime = this.elapsedTime;
		if (this.currTime - this.lastFps > 1000L) {
			System.out.println("FPS: " + this.fps);
			this.lastFps = this.currTime;
			this.fps = 0;
		}
		++this.fps;
		
		Gdx.gl.glClearColor(1, 1, 1, 1);
		Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);
		
		// set up stuff and draw
		batch.setProjectionMatrix(camera.combined);
		batch.begin();		
		draw();
		batch.end();		
		

	}

	////
	private void tick() {
		tweenManager.update(Constants.DELTA); // update 60 times a sec, roughly
		this.sceneStack.peek().tick();
	}
	private void draw() {
		this.sceneStack.peek().render();
	}
	
	////
	
	public void push(Scene scene) {
		this.sceneStack.push(scene);
		Engine.curr = scene;
		scene.init();
	}
	
	////
	
	@Override
	public void resize(int width, int height) {
		w = Gdx.graphics.getWidth();
		h = Gdx.graphics.getHeight();
		widthFactor = w / width;
		heightFactor = h / height;
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}
}
