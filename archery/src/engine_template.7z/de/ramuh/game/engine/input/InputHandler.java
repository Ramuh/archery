package de.ramuh.game.engine.input;

import com.badlogic.gdx.input.GestureDetector.GestureListener;
import com.badlogic.gdx.math.Vector2;

import de.ramuh.game.engine.Engine;

public class InputHandler implements GestureListener {

	@Override
	public boolean touchDown(float x, float y, int pointer, int button) {
		return false;
		//return ld.app.curr.touchDown(Math.round(x*ld.widthFactor), Math.round(y*ld.heightFactor), pointer, button);
	}

	@Override
	public boolean tap(float x, float y, int count, int button) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean longPress(float x, float y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean fling(float velocityX, float velocityY, int button) {
		return false;
		//return ld.app.curr.fling(velocityX, velocityY, button);
	}

	@Override
	public boolean pan(float x, float y, float deltaX, float deltaY) {
		// TODO Auto-generated method stub
		return Engine.curr.pan(Math.round(x*Engine.widthFactor), Math.round(y*Engine.widthFactor), Math.round(deltaX*Engine.widthFactor), Math.round(deltaY*Engine.widthFactor));
	}

	@Override
	public boolean zoom(float initialDistance, float distance) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean pinch(Vector2 initialPointer1, Vector2 initialPointer2,
			Vector2 pointer1, Vector2 pointer2) {
		// TODO Auto-generated method stub
		return false;
	}
}
