package de.ramuh.game.engine.components;

public class DisplayComponent {

}
