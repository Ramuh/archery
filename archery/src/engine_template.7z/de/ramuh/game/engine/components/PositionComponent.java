package de.ramuh.game.engine.components;

public class PositionComponent {
	public int x;
	public int y;
	public int rotation;
}
