package de.ramuh.game.engine.components;

public class VelocityComponent {
	public int velocityX;
	public int velocityY;
	public int angularVelocity;
}
